def minimo(x,y):
    if x>=y:        # 1 Comparación
        return y    # 1 Devolución
    else:
        return x    # 1 Devolución

# Coste = 1 + max(1,1)
# Coste = 2